pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()  // Add this line to resolve plugins like KSP
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)  // Ensure we are using central repositories
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "MarvelHeroes"
include(":app")
