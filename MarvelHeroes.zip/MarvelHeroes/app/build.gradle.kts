plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.dagger.hilt.android")
    id("com.google.devtools.ksp")  // Ensure KSP is applied here
    id("kotlin-kapt")  // Add the Kotlin Kapt plugin
}

android {
    namespace = "com.example.marvelheroes"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.marvelheroes"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }

    kotlinOptions {
        jvmTarget = "11"
        freeCompilerArgs += "-Xjvm-default=all"
    }

    buildFeatures {
        compose = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.10.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.6.1")
    implementation("androidx.activity:activity-compose:1.5.0")
    implementation("androidx.compose.ui:ui:1.2.0")
    implementation("androidx.compose.material3:material3:1.0.0")
    implementation("com.google.dagger:hilt-android:2.44")

    // For Hilt
    kapt("com.google.dagger:hilt-android-compiler:2.44")  // Correct KAPT for Hilt

    // Moshi (for JSON parsing)
    implementation("com.squareup.moshi:moshi-kotlin:1.15.0")
    ksp("com.squareup.moshi:moshi-kotlin-codegen:1.15.0")

    // Retrofit (for HTTP client)
    implementation("com.squareup.retrofit2:retrofit:2.9.0")
    implementation("com.squareup.retrofit2:converter-moshi:2.9.0")

    // OkHttp (for logging HTTP requests)
    implementation("com.squareup.okhttp3:logging-interceptor:5.0.0-alpha.3")

    // ViewModel for Compose
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.6.1")

    // Jetpack Compose Navigation
    implementation("androidx.navigation:navigation-compose:2.7.2")

    // Coil (for image loading)
    implementation("io.coil-kt:coil-compose:2.2.2")
}
