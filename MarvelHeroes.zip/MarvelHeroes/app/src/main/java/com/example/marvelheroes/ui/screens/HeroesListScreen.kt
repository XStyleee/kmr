package com.example.marvelheroes.ui.screens

import androidx.compose.foundation.*
import androidx.compose.runtime.*
import kotlinx.coroutines.launch
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextAlign
import coil.compose.rememberAsyncImagePainter
import androidx.navigation.NavController
import com.example.marvelheroes.data.HeroRepository
import com.example.marvelheroes.model.MarvelHero
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.ExperimentalFoundationApi

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HeroesListScreen(navController: NavController) {
    val heroes = remember { mutableStateOf<List<MarvelHero>>(emptyList()) }
    val coroutineScope = rememberCoroutineScope()
    val isError = remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        coroutineScope.launch {
            val result = HeroRepository.getHeroes()
            if (result.isEmpty()) {
                isError.value = true
            } else {
                heroes.value = result
            }
        }
    }

    if (isError.value) {
        Text(text = "Ошибка загрузки данных. Проверьте интернет-соединение!", color = Color.Red)
    } else {
        LazyRow {
            items(heroes.value) { hero ->
                HeroItem(
                    hero = hero,
                    onClick = { navController.navigate("heroDetail/${hero.id}") }
                )
            }
        }
    }
}

@Composable
fun HeroItem(hero: MarvelHero, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .width(300.dp)
            .height(450.dp)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp)
            .shadow(12.dp, RoundedCornerShape(24.dp))
    ) {
        // Фоновое изображение героя
        Image(
            painter = rememberAsyncImagePainter(hero.imageUrl),
            contentDescription = hero.name,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        // Затемненный градиент для читаемости текста
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    brush = Brush.verticalGradient(
                        colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.7f))
                    )
                )
        )

        // Имя героя
        Text(
            text = hero.name,
            color = Color.White,
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(16.dp)
        )
    }
}

