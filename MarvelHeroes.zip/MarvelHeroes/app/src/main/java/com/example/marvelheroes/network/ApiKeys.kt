package com.example.marvelheroes.network

import java.math.BigInteger
import java.security.MessageDigest

object ApiKeys {
    const val BASE_URL = "https://gateway.marvel.com/v1/public/"
    const val PUBLIC_KEY = "e9780542b35c7cef200ffd0cad9de039"
    private const val PRIVATE_KEY = "5ead18d0537e7af648ccb13a3f6d3dda4fabbe4b"

    fun generateHash(ts: String): String {
        val input = "$ts$PRIVATE_KEY$PUBLIC_KEY"
        val md = MessageDigest.getInstance("MD5")
        return BigInteger(1, md.digest(input.toByteArray())).toString(16).padStart(32, '0')
    }
}