package com.example.marvelheroes.model

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class MarvelResponse(
    val data: MarvelData
)

@JsonClass(generateAdapter = true)
data class MarvelData(
    val results: List<MarvelHero>
)

@JsonClass(generateAdapter = true)
data class MarvelHero(
    val id: Int,
    val name: String,
    val description: String,
    val thumbnail: Thumbnail
) {
    val imageUrl: String
        get() = "${thumbnail.path}.${thumbnail.extension}".replace("http://", "https://")
}

@JsonClass(generateAdapter = true)
data class Thumbnail(
    val path: String,
    val extension: String
)
