package com.example.marvelheroes.navigation

import android.os.Bundle
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.marvelheroes.data.HeroRepository
import com.example.marvelheroes.ui.screens.HeroDetailScreen
import com.example.marvelheroes.ui.screens.HeroesListScreen


@Composable
fun NavGraph(modifier: Modifier = Modifier) {
    val navController: NavHostController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = "heroesList",
        modifier = modifier
    ) {
        composable("heroesList") {
            HeroesListScreen(navController)
        }

        composable("heroDetail/{heroId}") { backStackEntry ->
            val heroId = backStackEntry.arguments?.getString("heroId")?.toIntOrNull()
            val viewModel: HeroesViewModel = hiltViewModel()

            val hero = viewModel.getHeroById(heroId)

            hero?.let {
                HeroDetailScreen(navController, it)
            }
        }


    }
}
