package com.example.marvelheroes.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.marvelheroes.model.MarvelHero
import com.example.marvelheroes.network.MarvelApiService
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.math.BigInteger
import java.security.MessageDigest
import javax.inject.Inject

@HiltViewModel
class HeroesViewModel @Inject constructor(
    private val marvelApiService: MarvelApiService
) : ViewModel() {

    private val _heroes = MutableStateFlow<List<MarvelHero>>(emptyList())
    val heroes: StateFlow<List<MarvelHero>> = _heroes.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    init {
        fetchHeroes()
    }

    private fun fetchHeroes() {
        viewModelScope.launch {
            try {
                val ts = System.currentTimeMillis().toString()
                val hash = generateHash(ts)
                val response = marvelApiService.getHeroes(
                    apiKey = "e9780542b35c7cef200ffd0cad9de039",
                    ts = ts,
                    hash = hash
                )
                _heroes.value = response.data.results
            } catch (e: Exception) {
                _error.value = "Ошибка загрузки данных: ${e.localizedMessage}"
            }
        }
    }

    fun getHeroById(heroId: Int?): MarvelHero? {
        return _heroes.value.find { it.id == heroId }
    }

    private fun generateHash(ts: String): String {
        val input = ts + "5ead18d0537e7af648ccb13a3f6d3dda4fabbe4b" + "e9780542b35c7cef200ffd0cad9de039"
        val md = MessageDigest.getInstance("MD5")
        return BigInteger(1, md.digest(input.toByteArray())).toString(16).padStart(32, '0')
    }
}
