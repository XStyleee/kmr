package com.example.marvelheroes.data

import com.example.marvelheroes.model.MarvelHero
import com.example.marvelheroes.network.ApiKeys
import com.example.marvelheroes.network.RetrofitInstance

object HeroRepository {
    suspend fun getHeroes(): List<MarvelHero> {
        val ts = System.currentTimeMillis().toString()
        val hash = ApiKeys.generateHash(ts)
        return try {
            RetrofitInstance.api.getHeroes(ts, ApiKeys.PUBLIC_KEY, hash).data.results
        } catch (e: Exception) {
            emptyList() // Возвращаем пустой список при ошибке
        }
    }

    suspend fun getHeroById(id: Int): MarvelHero? {
        val ts = System.currentTimeMillis().toString()
        val hash = ApiKeys.generateHash(ts)
        return try {
            RetrofitInstance.api.getHeroById(id, ts, ApiKeys.PUBLIC_KEY, hash).data.results.firstOrNull()
        } catch (e: Exception) {
            null // Возвращаем null при ошибке
        }
    }
}
