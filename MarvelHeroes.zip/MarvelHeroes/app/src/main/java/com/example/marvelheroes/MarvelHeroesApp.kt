package com.example.marvelheroes

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class MarvelHeroesApp : Application()
